package com.example.azuretranslation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.net.ResponseCache;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    Retrofit retrofit = new Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(AzureTranslationAPI.API_URL)
            .build();

    AzureTranslationAPI api = retrofit.create(AzureTranslationAPI.class);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Call<Translation> call = api.getLanguages();
        call.enqueue(new LanguagesCallback());
    }

    static class LanguagesCallback implements Callback<Translation> {

        @Override
        public void onResponse(Call<Translation> call, Response<Translation> response) {
            if (response.isSuccessful()) {
                Log.d("mytag", "response: " + response.body());
            } else
                Log.d("mytag", "error" + response.code());
        }

        @Override
        public void onFailure(Call<Translation> call, Throwable t) {
            Log.d("mytag", "error" + t.getLocalizedMessage());
        }
    }
}