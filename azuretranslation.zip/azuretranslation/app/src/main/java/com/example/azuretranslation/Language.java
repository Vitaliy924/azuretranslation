package com.example.azuretranslation;

public class Language {
    String name, nativeName;
}
